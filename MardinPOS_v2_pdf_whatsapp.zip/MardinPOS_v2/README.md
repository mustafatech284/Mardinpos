# Mardin POS v2 — PDF + WhatsApp workflow

Implemented design:
- Store market name, owner name, phone/WhatsApp number.
- Generate invoice PDF.
- Save invoice locally.
- Open WhatsApp with a prepared message and attach/share the PDF through Android share flow.

Important limitation:
A normal Android app cannot silently send an arbitrary PDF to a WhatsApp number without user confirmation. Fully automatic sending requires an approved WhatsApp Business Platform/API integration, business verification, templates, and a backend. The safe v2 flow therefore prepares the PDF and opens WhatsApp/share sheet for confirmation.

Next build requirements:
- Android Studio + Android SDK
- Room database for local storage
- Cloud backend/auth for multi-device sync
- FileProvider for PDF sharing
- Optional WhatsApp Business Cloud API backend for approved automated delivery
