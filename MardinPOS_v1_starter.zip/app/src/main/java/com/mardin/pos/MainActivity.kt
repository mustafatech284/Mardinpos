package com.mardin.pos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Product(val name:String, val buy:Double, val sell:Double, val stock:Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MardinPOSApp() }
    }
}

@Composable
fun MardinPOSApp() {
    var tab by remember { mutableStateOf(0) }
    var products by remember { mutableStateOf(listOf(
        Product("فڵچەی ددان", 1000.0, 1500.0, 50),
        Product("معجونی ددان", 2000.0, 3000.0, 40)
    )) }
    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Mardin POS") }) },
            bottomBar = {
                NavigationBar {
                    listOf("کۆگا","فرۆشتن","قەرز").forEachIndexed { i, label ->
                        NavigationBarItem(selected=tab==i, onClick={tab=i}, icon={}, label={Text(label)})
                    }
                }
            }
        ) { pad ->
            Column(Modifier.padding(pad).padding(16.dp)) {
                when(tab) {
                    0 -> {
                        Text("کۆگای کاڵاکان", style=MaterialTheme.typography.headlineSmall)
                        Spacer(Modifier.height(12.dp))
                        LazyColumn {
                            items(products) { p ->
                                Card(Modifier.fillMaxWidth().padding(vertical=4.dp)) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text(p.name, style=MaterialTheme.typography.titleMedium)
                                        Text("کڕین: ${p.buy} | فرۆشتن: ${p.sell}")
                                        Text("ماوە: ${p.stock} دانە")
                                    }
                                }
                            }
                        }
                    }
                    1 -> {
                        Text("فرۆشتن", style=MaterialTheme.typography.headlineSmall)
                        Text("وەشانی یەکەم: بنەمای فرۆشتن لێرە زیاد دەکرێت.")
                    }
                    2 -> {
                        Text("قەرزی مارکێتەکان", style=MaterialTheme.typography.headlineSmall)
                        Text("وەشانی یەکەم: تۆمارکردنی قەرز و پارەدان لە قۆناغی داهاتووە.")
                    }
                }
            }
        }
    }
}
